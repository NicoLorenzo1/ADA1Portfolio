namespace ProyectoUT5
{
    public class Team
    {
        public string TeamName { get; set; }
        public string Discipline { get; set; }
        public List<Participant> Participants { get; set; }
        public int Score { get; set; }
    }
}
