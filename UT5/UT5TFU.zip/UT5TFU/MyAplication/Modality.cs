namespace ProyectoUT5
{
    public class Modality
    {
        public string? Nombre { get; set; }
        public string? Descripcion { get; set; }
        public List<string>? Distancias { get; set; }
        public List<Category>? Categorias { get; set; }
    }
}
