namespace ProyectoUT5
{
    public class Category
    {
        public string? Nombre { get; set; }
        public string? Descripcion { get; set; }
        public List<string>? Distancias { get; set; }
        public List<string>? Modalidades { get; set; }
        public List<string>? Opciones { get; set; }
    }
}