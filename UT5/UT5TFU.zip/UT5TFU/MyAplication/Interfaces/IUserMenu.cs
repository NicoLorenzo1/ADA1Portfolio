namespace ProyectoUT5
{
    public interface IUserMenu
    {
        void ShowMenu();
    }
}
