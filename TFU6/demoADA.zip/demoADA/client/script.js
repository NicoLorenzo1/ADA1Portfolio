document.addEventListener('DOMContentLoaded', () => {
    const taskForm = document.getElementById('task-form');
    const taskInput = document.getElementById('task-input');
    const taskList = document.getElementById('task-list');
    const addTaskButton = document.querySelector('button.add-task');

    const apiUrl = 'http://localhost:5001/tasks';

    let isEditing = false;
    let editTaskId = null;

    // Habilitar/Deshabilitar botón "Add Task"
    const toggleAddTaskButton = () => {
        addTaskButton.disabled = taskInput.value.trim() === '';
    };

    taskInput.addEventListener('input', toggleAddTaskButton);

    // Fetch and display tasks
    const fetchTasks = async () => {
        const response = await fetch(apiUrl);
        const tasks = await response.json();
        taskList.innerHTML = '';
        tasks.forEach(task => {
            const li = document.createElement('li');
            li.textContent = task.title;
            li.dataset.id = task._id;
            if (task.completed) {
                li.classList.add('completed');
            }
            const buttonContainer = document.createElement('div');
            buttonContainer.classList.add('task-buttons');

            const deleteButton = document.createElement('button');
            deleteButton.textContent = 'Delete';
            deleteButton.classList.add('delete-task');
            deleteButton.addEventListener('click', async () => {
                await fetch(`${apiUrl}/${task._id}`, { method: 'DELETE' });
                fetchTasks();
            });

            const editButton = document.createElement('button');
            editButton.textContent = 'Edit';
            editButton.classList.add('edit-task');
            editButton.addEventListener('click', () => {
                taskInput.value = task.title;
                isEditing = true;
                editTaskId = task._id;
                toggleAddTaskButton();
            });

            const toggleButton = document.createElement('button');
            toggleButton.textContent = task.completed ? 'Undo' : 'Complete';
            toggleButton.classList.add(task.completed ? 'undo-task' : 'complete-task');
            toggleButton.addEventListener('click', async () => {
                await fetch(`${apiUrl}/${task._id}`, {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ completed: !task.completed })
                });
                fetchTasks();
            });

            buttonContainer.appendChild(toggleButton);
            buttonContainer.appendChild(editButton);
            buttonContainer.appendChild(deleteButton);

            li.appendChild(buttonContainer);
            taskList.appendChild(li);
        });
    };

    taskForm.addEventListener('submit', async (event) => {
        event.preventDefault();
        const newTask = { title: taskInput.value, completed: false };

        if (isEditing) {
            await fetch(`${apiUrl}/${editTaskId}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(newTask)
            });
            isEditing = false;
            editTaskId = null;
        } else {
            await fetch(apiUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(newTask)
            });
        }

        taskInput.value = '';
        toggleAddTaskButton();
        fetchTasks();
    });

    fetchTasks();
    toggleAddTaskButton(); // Initial call to set the correct state of the button
});
